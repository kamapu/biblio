biblio 0.0.3
============

### New Features

* New function `read_ris()`to import RIS files.
* Internal data in the object `biblio:::data_bib`.

### Improvements

### Bug Fixes

biblio 0.0.3
============

### New Features

* New function `read_ris()`to import RIS files.
* Internal data in the object `biblio:::data_bib`.

### Improvements

### Bug Fixes

* Function `read_bib()` was not working properly if the last tag in an entry
  did not ended with a comma. Now it is solved

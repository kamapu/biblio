context("creating empty reference lists")

test_that("a 'lib_df' is created", {
			expect_is(new_lib(), "lib_df")
		})

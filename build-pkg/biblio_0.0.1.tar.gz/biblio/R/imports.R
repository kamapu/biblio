#' @importFrom utils browseURL
#' @importFrom stats na.omit aggregate
#' @importFrom stringr str_extract str_trim
#' @importFrom yamlme read_rmd write_rmd render_rmd
NULL

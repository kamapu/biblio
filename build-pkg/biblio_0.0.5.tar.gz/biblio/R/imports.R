#' @importFrom stats na.omit aggregate
#' @importFrom stringr fixed regex str_count str_match_all str_trim 
#' @importFrom yamlme write_rmd
#' @importFrom methods setOldClass
NULL
